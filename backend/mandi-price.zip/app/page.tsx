import { MandiPricesApp } from "@/components/mandi-prices-app"

export default function Home() {
  return <MandiPricesApp />
}
